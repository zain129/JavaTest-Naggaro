package com.zainimtiaz.nagarro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NagarroApplication {

	public static void main(String[] args) {
		SpringApplication.run(NagarroApplication.class, args);
	}

}
